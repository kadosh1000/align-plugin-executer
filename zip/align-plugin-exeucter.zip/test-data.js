/**
 * Here is some test data in order to test the `getMessageJson` method
 */
//  const processes = {
//     "8b40a89e-a4b3-4e4f-9368-3e16c8ae228e": [
//         {
//             "status": "done",
//             "startNode": true
//         }
//     ],
//     "70c1e598-f72a-4ab0-afa2-78959c47e5ad": [
//         {
//             "processId": "6088031ba2ab2d0035cb273b",
//             "iterationIndex": 0,
//             "status": "done",
//             "uuid": "70c1e598-f72a-4ab0-afa2-78959c47e5ad",
//             "actions": {
//                 "6088031ba2ab2d0035cb273c": {
//                     "retries": 0,
//                     "mandatory": null,
//                     "isEnabled": true,
//                     "params": [
//                         {
//                             "_id": "6088031ba2ab2d0035cb273d",
//                             "code": true,
//                             "value": "wcm_admin_user()",
//                             "param": null,
//                             "name": "username"
//                         },
//                         {
//                             "_id": "6088031ba2ab2d0035cb273e",
//                             "code": true,
//                             "value": "wcm_admin_password()",
//                             "param": null,
//                             "name": "password"
//                         },
//                         {
//                             "_id": "6088031ba2ab2d0035cb273f",
//                             "code": null,
//                             "value": "60589ed16f02ea0011c58960",
//                             "param": null,
//                             "name": "mandatory_block"
//                         }
//                     ],
//                     "_id": "6088031ba2ab2d0035cb273c",
//                     "name": "Action #1 ",
//                     "timeout": null,
//                     "method": "Login",
//                     "numParallel": null,
//                     "actionExecutionId": "8540b52e-0edc-4bf9-b64d-c5a76e57ba29-1620654317416",
//                     "action": "6088031ba2ab2d0035cb273c",
//                     "startTime": "2021-05-10T13:45:17.416Z",
//                     "retriesLeft": 0,
//                     "status": "success",
//                     "result": {
//                         "stdout": "+ myitero-lab - Login: username: , password: , mandatory_block: undefined",
//                         "stderr": "",
//                         "result": JSON.stringify(
//                             {
//                                 "stage": "mat",
//                                 "method": "${method}",
//                                 "status": "",
//                                 "retries": 1,
//                                 "attempts": 0,
//                                 "user_name": "${action.params.username}",
//                                 "order_id": "${action.params.order_id}",
//                                 "exception": "",
//                                 "next_step": "",
//                                 "order_information_fields": [],
//                                 "work_orders_fields": [],
//                                 "rx_deafult": true,
//                                 "rx_fields": []
//                         })
//                     },
//                     "finishTime": "2021-05-10T13:45:17.487Z"
//                 },
//                 // "6088031ba2ab2d0035cb2740": {
//                 //     "retries": 0,
//                 //     "mandatory": null,
//                 //     "isEnabled": true,
//                 //     "params": [
//                 //         {
//                 //             "_id": "6088031ba2ab2d0035cb2741",
//                 //             "code": null,
//                 //             "value": null,
//                 //             "param": null,
//                 //             "name": "order_id"
//                 //         }
//                 //     ],
//                 //     "_id": "6088031ba2ab2d0035cb2740",
//                 //     "name": "Action #2 ",
//                 //     "timeout": null,
//                 //     "method": "Search_Order",
//                 //     "numParallel": null,
//                 //     "actionExecutionId": "f355c353-fd9d-4179-bca4-2770564290ae-1620654317494",
//                 //     "action": "6088031ba2ab2d0035cb2740",
//                 //     "startTime": "2021-05-10T13:45:17.494Z",
//                 //     "retriesLeft": 0,
//                 //     "status": "success",
//                 //     "result": {
//                 //         "stdout": "+ myitero-lab - Search_Order: order_id: null",
//                 //         "stderr": "",
//                 //         "result": JSON.stringify({'name': 'Search_Order','params': {'order_id': 'null'}})
//                 //     },
//                 //     "finishTime": "2021-05-10T13:45:17.548Z"
//                 // }
//             },
//             "startTime": "2021-05-10T13:45:17.398Z",
//             "processIndex": 0,
//             "processName": "Process #1",
//             "finishTime": "2021-05-10T13:45:17.555Z"
//         }
//     ]
// };

 const processes = {
    "8b40a89e-a4b3-4e4f-9368-3e16c8ae228e": [
        {
            "status": "done",
            "startNode": true
        }
    ],
    "bdf04dac-281c-42ee-a2d9-68947043a4d3": [
        {
            "processId": "609cd9e8158d6600346da230",
            "iterationIndex": 0,
            "status": "done",
            "uuid": "bdf04dac-281c-42ee-a2d9-68947043a4d3",
            "actions": {
                "609cdc6a158d6600346e76b0": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "609cdc6a158d6600346e76b1",
                            "code": true,
                            "value": "myitero_lab_user()",
                            "param": "609cd9e8158d6600346da232",
                            "name": "username"
                        },
                        {
                            "_id": "609cdc6a158d6600346e76b2",
                            "code": true,
                            "value": "myitero_lab_password()",
                            "param": "609cd9e8158d6600346da233",
                            "name": "password"
                        },
                        {
                            "_id": "609cdc6a158d6600346e76b3",
                            "code": null,
                            "value": "Yes",
                            "param": "609cd9e8158d6600346da234",
                            "name": "mandatory_block"
                        }
                    ],
                    "_id": "609cdc6a158d6600346e76b0",
                    "name": "Login",
                    "timeout": null,
                    "method": "Login",
                    "numParallel": null,
                    "actionExecutionId": "afe3531d-20e6-4ece-8f4b-50e2d5f6bea7-1620897483428",
                    "action": "609cdc6a158d6600346e76b0",
                    "startTime": "2021-05-13T09:18:03.428Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - Login: username: kauslab1@gmail.com, password: Aligner5, mandatory_block: Yes",
                        "stderr": "",
                        "result": "{\"name\": \"Login\",\"params\": {\"user_name\":\"kauslab1@gmail.com\",\"password\": \"Aligner5\",\"mandatory_block\": true}}"
                    },
                    "finishTime": "2021-05-13T09:18:03.491Z"
                },
                "609cdc6a158d6600346e76b4": {
                    "retries": 5,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "609cdc6a158d6600346e76b5",
                            "code": false,
                            "value": "",
                            "param": "609cd9e8158d6600346da236",
                            "name": "order_id"
                        }
                    ],
                    "_id": "609cdc6a158d6600346e76b4",
                    "name": "Search Order",
                    "timeout": null,
                    "method": "Search_Order",
                    "numParallel": null,
                    "actionExecutionId": "a6c79980-7d3c-4b78-86a2-1d133e089c8b-1620897483499",
                    "action": "609cdc6a158d6600346e76b4",
                    "startTime": "2021-05-13T09:18:03.499Z",
                    "retriesLeft": 5,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - Search_Order: order_id: ",
                        "stderr": "",
                        "result": "{\"name\": \"Search_Order\",\"params\": {\"order_id\": \"\"}}"
                    },
                    "finishTime": "2021-05-13T09:18:03.554Z"
                },
                "609cdc6a158d6600346e76b6": {
                    "retries": 5,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "609cdc6a158d6600346e76b7",
                            "code": false,
                            "value": "",
                            "param": "609cd9e8158d6600346da238",
                            "name": "order_id"
                        },
                        {
                            "_id": "609cdc6a158d6600346e76b8",
                            "code": null,
                            "value": null,
                            "param": "609cd9e8158d6600346da239",
                            "name": "rx_fields"
                        },
                        {
                            "_id": "609cdc6a158d6600346e76b9",
                            "code": null,
                            "value": null,
                            "param": "609cd9e8158d6600346da23a",
                            "name": "rx_deafult"
                        },
                        {
                            "_id": "609cdc6a158d6600346e76ba",
                            "code": null,
                            "value": "Yes",
                            "param": "609cd9e8158d6600346da23b",
                            "name": "Go_Back_When_Done"
                        }
                    ],
                    "_id": "609cdc6a158d6600346e76b6",
                    "name": "ViewRx",
                    "timeout": null,
                    "method": "ViewRx",
                    "numParallel": null,
                    "actionExecutionId": "d5f2fc92-c3f8-4ab0-a770-f47930c22213-1620897483564",
                    "action": "609cdc6a158d6600346e76b6",
                    "startTime": "2021-05-13T09:18:03.564Z",
                    "retriesLeft": 5,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - ViewRx: order_id: , rx_fields: null, rx_deafult: null, Go_Back_When_Done: Yes",
                        "stderr": "",
                        "result": "{\"name\": \"ViewRX\",\"params\": {\"order_id\": \"\",\"rx_deafult\": null,\"Go_Back_When_Done\": true,\"rx_fields\": null}}"
                    },
                    "finishTime": "2021-05-13T09:18:03.621Z"
                },
                "609cdc6a158d6600346e76bb": {
                    "retries": 5,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "609cdc6a158d6600346e76bc",
                            "code": false,
                            "value": "",
                            "param": "609cd9e8158d6600346da23d",
                            "name": "order_id"
                        }
                    ],
                    "_id": "609cdc6a158d6600346e76bb",
                    "name": "SearchOrder",
                    "timeout": null,
                    "method": "Search_Order",
                    "numParallel": null,
                    "actionExecutionId": "9940a0ec-4e3d-4351-8226-bece469ce21b-1620897483628",
                    "action": "609cdc6a158d6600346e76bb",
                    "startTime": "2021-05-13T09:18:03.628Z",
                    "retriesLeft": 5,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - Search_Order: order_id: ",
                        "stderr": "",
                        "result": "{\"name\": \"Search_Order\",\"params\": {\"order_id\": \"\"}}"
                    },
                    "finishTime": "2021-05-13T09:18:03.682Z"
                },
                "609cdc6a158d6600346e76bd": {
                    "retries": 5,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "609cdc6a158d6600346e76be",
                            "code": false,
                            "value": "",
                            "param": "609cd9e8158d6600346da23f",
                            "name": "order_id"
                        },
                        {
                            "_id": "609cdc6a158d6600346e76bf",
                            "code": null,
                            "value": "No",
                            "param": "609cd9e8158d6600346da240",
                            "name": "jaws_verification"
                        },
                        {
                            "_id": "609cdc6a158d6600346e76c0",
                            "code": null,
                            "value": "Yes",
                            "param": "609cd9e8158d6600346da241",
                            "name": "Go_Back_When_Done"
                        }
                    ],
                    "_id": "609cdc6a158d6600346e76bd",
                    "name": "Viewer",
                    "timeout": null,
                    "method": "View",
                    "numParallel": null,
                    "actionExecutionId": "30f957a1-9e76-44f8-86c5-480babf9a524-1620897483689",
                    "action": "609cdc6a158d6600346e76bd",
                    "startTime": "2021-05-13T09:18:03.689Z",
                    "retriesLeft": 5,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - View: order_id: , jaws_verification: No, Go_Back_When_Done: Yes",
                        "stderr": "",
                        "result": "{\"name\": \"View\",\"params\": {\"order_id\": \"\",\"jaws_verification\": false,\"Go_Back_When_Done\": true}}"
                    },
                    "finishTime": "2021-05-13T09:18:03.746Z"
                },
                "609cdc6a158d6600346e76c1": {
                    "retries": 5,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [],
                    "_id": "609cdc6a158d6600346e76c1",
                    "name": "Physical Model Request",
                    "timeout": null,
                    "method": "iTero_Services",
                    "numParallel": null,
                    "actionExecutionId": "51b91e6b-c527-4cca-a981-758b96087953-1620897483753",
                    "action": "609cdc6a158d6600346e76c1",
                    "startTime": "2021-05-13T09:18:03.753Z",
                    "retriesLeft": 5,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - iTero_Services: ",
                        "stderr": "",
                        "result": "{\"name\": \"iTero_Services\",\"params\": {\"order_id\": \"undefined\",\"itero_service\": \"undefined\",\"number_of_models\": undefined,\"additional_dies\": undefined,\"die_ditch\": \"true\"}}"
                    },
                    "finishTime": "2021-05-13T09:18:03.808Z"
                }
            },
            "startTime": "2021-05-13T09:18:03.393Z",
            "processIndex": 0,
            "processName": "myitero-lab (copy)",
            "finishTime": "2021-05-13T09:18:03.816Z"
        }
    ],
    "9e285ff6-9faa-4424-99b4-4ea16494327f": [
        {
            "processId": "609c0c47447627003f948447",
            "iterationIndex": 0,
            "status": "running",
            "uuid": "9e285ff6-9faa-4424-99b4-4ea16494327f",
            "actions": {
                "609cd9e8158d6600346da22b": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "609cd9e8158d6600346da22c",
                            "code": true,
                            "value": "print()",
                            "param": "609c0c47447627003f948449",
                            "name": "COMMANDS"
                        }
                    ],
                    "_id": "609cd9e8158d6600346da22b",
                    "name": "Action #1 ",
                    "timeout": null,
                    "method": "execute",
                    "numParallel": null,
                    "actionExecutionId": "3d6048da-7779-4a57-b9df-8f0b54fda1e4-1620897483846",
                    "action": "609cd9e8158d6600346da22b",
                    "startTime": "2021-05-13T09:18:03.846Z",
                    "retriesLeft": 0,
                    "status": "running"
                }
            },
            "startTime": "2021-05-13T09:18:03.825Z",
            "processIndex": 1,
            "processName": "print"
        }
    ]
}

const configuration = {
	"uuid": "",
    "uniqe_suffix":"",
	"name": "Restorative_Case_One_Prep_E2E",
	"order_id": "",
	"environment": "ppr",
	"worker_number": 1,
	"json_folder": "",
    "test":"ITEROBIZ-56520 - D2L - ACS - physical model request + Notifications flow - EU region",
    "debug_report_name":"PPR_logs",
	"current_stage": "stage_1",
    "unique_scanner":false,
    "scanner_agent_tags":""
};

module.exports = {processes, configuration}


