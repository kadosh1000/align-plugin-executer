/**
 * Here is some test data in order to test the `getMessageJson` method
 */
//  const processes = {
//     "8b40a89e-a4b3-4e4f-9368-3e16c8ae228e": [
//         {
//             "status": "done",
//             "startNode": true
//         }
//     ],
//     "70c1e598-f72a-4ab0-afa2-78959c47e5ad": [
//         {
//             "processId": "6088031ba2ab2d0035cb273b",
//             "iterationIndex": 0,
//             "status": "done",
//             "uuid": "70c1e598-f72a-4ab0-afa2-78959c47e5ad",
//             "actions": {
//                 "6088031ba2ab2d0035cb273c": {
//                     "retries": 0,
//                     "mandatory": null,
//                     "isEnabled": true,
//                     "params": [
//                         {
//                             "_id": "6088031ba2ab2d0035cb273d",
//                             "code": true,
//                             "value": "wcm_admin_user()",
//                             "param": null,
//                             "name": "username"
//                         },
//                         {
//                             "_id": "6088031ba2ab2d0035cb273e",
//                             "code": true,
//                             "value": "wcm_admin_password()",
//                             "param": null,
//                             "name": "password"
//                         },
//                         {
//                             "_id": "6088031ba2ab2d0035cb273f",
//                             "code": null,
//                             "value": "60589ed16f02ea0011c58960",
//                             "param": null,
//                             "name": "mandatory_block"
//                         }
//                     ],
//                     "_id": "6088031ba2ab2d0035cb273c",
//                     "name": "Action #1 ",
//                     "timeout": null,
//                     "method": "Login",
//                     "numParallel": null,
//                     "actionExecutionId": "8540b52e-0edc-4bf9-b64d-c5a76e57ba29-1620654317416",
//                     "action": "6088031ba2ab2d0035cb273c",
//                     "startTime": "2021-05-10T13:45:17.416Z",
//                     "retriesLeft": 0,
//                     "status": "success",
//                     "result": {
//                         "stdout": "+ myitero-lab - Login: username: , password: , mandatory_block: undefined",
//                         "stderr": "",
//                         "result": JSON.stringify(
//                             {
//                                 "stage": "mat",
//                                 "method": "${method}",
//                                 "status": "",
//                                 "retries": 1,
//                                 "attempts": 0,
//                                 "user_name": "${action.params.username}",
//                                 "order_id": "${action.params.order_id}",
//                                 "exception": "",
//                                 "next_step": "",
//                                 "order_information_fields": [],
//                                 "work_orders_fields": [],
//                                 "rx_deafult": true,
//                                 "rx_fields": []
//                         })
//                     },
//                     "finishTime": "2021-05-10T13:45:17.487Z"
//                 },
//                 // "6088031ba2ab2d0035cb2740": {
//                 //     "retries": 0,
//                 //     "mandatory": null,
//                 //     "isEnabled": true,
//                 //     "params": [
//                 //         {
//                 //             "_id": "6088031ba2ab2d0035cb2741",
//                 //             "code": null,
//                 //             "value": null,
//                 //             "param": null,
//                 //             "name": "order_id"
//                 //         }
//                 //     ],
//                 //     "_id": "6088031ba2ab2d0035cb2740",
//                 //     "name": "Action #2 ",
//                 //     "timeout": null,
//                 //     "method": "Search_Order",
//                 //     "numParallel": null,
//                 //     "actionExecutionId": "f355c353-fd9d-4179-bca4-2770564290ae-1620654317494",
//                 //     "action": "6088031ba2ab2d0035cb2740",
//                 //     "startTime": "2021-05-10T13:45:17.494Z",
//                 //     "retriesLeft": 0,
//                 //     "status": "success",
//                 //     "result": {
//                 //         "stdout": "+ myitero-lab - Search_Order: order_id: null",
//                 //         "stderr": "",
//                 //         "result": JSON.stringify({'name': 'Search_Order','params': {'order_id': 'null'}})
//                 //     },
//                 //     "finishTime": "2021-05-10T13:45:17.548Z"
//                 // }
//             },
//             "startTime": "2021-05-10T13:45:17.398Z",
//             "processIndex": 0,
//             "processName": "Process #1",
//             "finishTime": "2021-05-10T13:45:17.555Z"
//         }
//     ]
// };

 const processes = {
    "8b40a89e-a4b3-4e4f-9368-3e16c8ae228e": [
        {
            "status": "done",
            "startNode": true
        }
    ],
    "32f80a9b-d144-429c-b81a-37fd62d20c5f": [
        {
            "processId": "606d98a80212a5001852f47c",
            "iterationIndex": 0,
            "status": "done",
            "uuid": "32f80a9b-d144-429c-b81a-37fd62d20c5f",
            "actions": {
                "606d98a80212a5001852f47d": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "605074d67e45b40019989863",
                            "code": true,
                            "value": "myitero_lab_user()",
                            "param": "604f8e97d2ad7e0011328723",
                            "name": "username"
                        },
                        {
                            "_id": "605074d67e45b40019989864",
                            "code": true,
                            "value": "myitero_lab_password()",
                            "param": "604f8e97d2ad7e0011328724",
                            "name": "password"
                        },
                        {
                            "_id": "605074d67e45b40019989865",
                            "code": null,
                            "value": "Yes",
                            "param": "604f8e97d2ad7e0011328725",
                            "name": "mandatory_block"
                        }
                    ],
                    "_id": "606d98a80212a5001852f47d",
                    "name": "Login",
                    "timeout": null,
                    "method": "Login",
                    "numParallel": null,
                    "actionExecutionId": "473a0a67-f299-491d-9f1c-d221b985937e-1621339576818",
                    "action": "606d98a80212a5001852f47d",
                    "startTime": "2021-05-18T12:06:16.818Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - Login: username: kauslab1@gmail.com, password: Aligner5, mandatory_block: Yes",
                        "stderr": "",
                        "result": "{\"name\": \"Login\",\"params\": {\"user_name\":\"kauslab1@gmail.com\",\"password\": \"Aligner5\",\"mandatory_block\": true}}"
                    },
                    "finishTime": "2021-05-18T12:06:16.881Z"
                },
                "606d98a80212a5001852f481": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "605074d67e45b40019989867",
                            "code": null,
                            "value": "",
                            "param": "604f8e97d2ad7e0011328727",
                            "name": "order_id"
                        }
                    ],
                    "_id": "606d98a80212a5001852f481",
                    "name": "Search Order",
                    "timeout": null,
                    "method": "Search_Order",
                    "numParallel": null,
                    "actionExecutionId": "acf32b7e-4225-4a4f-a47e-42f614cecb53-1621339576888",
                    "action": "606d98a80212a5001852f481",
                    "startTime": "2021-05-18T12:06:16.888Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - Search_Order: order_id: ",
                        "stderr": "",
                        "result": "{\"name\": \"Search_Order\",\"params\": {\"order_id\": \"\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:16.945Z"
                },
                "606d98a80212a5001852f483": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "605074d67e45b40019989869",
                            "code": null,
                            "value": null,
                            "param": "604f8e97d2ad7e0011328729",
                            "name": "order_id"
                        },
                        {
                            "_id": "605074d67e45b4001998986a",
                            "code": null,
                            "value": null,
                            "param": "604f8e97d2ad7e001132872a",
                            "name": "rx_fields"
                        },
                        {
                            "_id": "605074d67e45b4001998986b",
                            "code": null,
                            "value": null,
                            "param": "604f8e97d2ad7e001132872b",
                            "name": "rx_deafult"
                        },
                        {
                            "_id": "605074d67e45b4001998986c",
                            "code": null,
                            "value": "Yes",
                            "param": "604f8e97d2ad7e001132872c",
                            "name": "Go_Back_When_Done"
                        }
                    ],
                    "_id": "606d98a80212a5001852f483",
                    "name": "ViewRx",
                    "timeout": null,
                    "method": "ViewRx",
                    "numParallel": null,
                    "actionExecutionId": "2639c780-bbba-4d23-bbae-50080080ef72-1621339576951",
                    "action": "606d98a80212a5001852f483",
                    "startTime": "2021-05-18T12:06:16.951Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - ViewRx: order_id: null, rx_fields: null, rx_deafult: null, Go_Back_When_Done: Yes",
                        "stderr": "",
                        "result": "{\"name\":\"ViewRX\",\"params\":{\"order_id\":null,\"rx_deafult\":\"true\",\"Go_Back_When_Done\":\"true\",\"rx_fields\":[]}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.008Z"
                },
                "606d98a80212a5001852f488": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "605074d67e45b4001998986e",
                            "code": null,
                            "value": "",
                            "param": "604f8e97d2ad7e001132872e",
                            "name": "order_id"
                        }
                    ],
                    "_id": "606d98a80212a5001852f488",
                    "name": "SearchOrder",
                    "timeout": null,
                    "method": "Search_Order",
                    "numParallel": null,
                    "actionExecutionId": "c785908b-47c0-43f4-b352-71672325a3ae-1621339577013",
                    "action": "606d98a80212a5001852f488",
                    "startTime": "2021-05-18T12:06:17.013Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - Search_Order: order_id: ",
                        "stderr": "",
                        "result": "{\"name\": \"Search_Order\",\"params\": {\"order_id\": \"\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.069Z"
                },
                "606d98a80212a5001852f48a": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "605074d67e45b40019989870",
                            "code": null,
                            "value": null,
                            "param": "604f8e97d2ad7e0011328730",
                            "name": "order_id"
                        },
                        {
                            "_id": "605074d67e45b40019989871",
                            "code": null,
                            "value": "No",
                            "param": "604f8e97d2ad7e0011328731",
                            "name": "jaws_verification"
                        },
                        {
                            "_id": "605074d67e45b40019989872",
                            "code": null,
                            "value": "No",
                            "param": "604f8e97d2ad7e0011328732",
                            "name": "Go_Back_When_Done"
                        }
                    ],
                    "_id": "606d98a80212a5001852f48a",
                    "name": "Viewer",
                    "timeout": null,
                    "method": "View",
                    "numParallel": null,
                    "actionExecutionId": "e322ad44-6bdf-410f-a9dd-dfda055e0db2-1621339577075",
                    "action": "606d98a80212a5001852f48a",
                    "startTime": "2021-05-18T12:06:17.075Z",
                    "retriesLeft": 0,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - View: order_id: null, jaws_verification: No, Go_Back_When_Done: No",
                        "stderr": "",
                        "result": "{\"name\": \"View\",\"params\": {\"order_id\": \"null\",\"jaws_verification\": false,\"Go_Back_When_Done\": false}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.130Z"
                },
                "606d98a80212a5001852f48e": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "605074d67e45b40019989874",
                            "code": null,
                            "value": null,
                            "param": "604f8e97d2ad7e0011328739",
                            "name": "order_id"
                        },
                        {
                            "_id": "605074d67e45b40019989875",
                            "code": null,
                            "value": null,
                            "param": "604f8e97d2ad7e001132873a",
                            "name": "CAD_CAM_System"
                        },
                        {
                            "_id": "605074d67e45b40019989876",
                            "code": null,
                            "value": null,
                            "param": "604f8e97d2ad7e001132873b",
                            "name": "Hide_patient_name"
                        }
                    ],
                    "_id": "606d98a80212a5001852f48e",
                    "name": "Export - iDE",
                    "timeout": null,
                    "method": "ExportResto",
                    "numParallel": null,
                    "actionExecutionId": "567a3373-ab9e-48d6-8fb7-b6ce358785a0-1621339577136",
                    "action": "606d98a80212a5001852f48e",
                    "startTime": "2021-05-18T12:06:17.136Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - ExportResto: order_id: null, CAD_CAM_System: null, Hide_patient_name: null",
                        "stderr": "",
                        "result": "{\"name\": \"Export_Restorative_Case\",\"params\": {\"order_id\": \"null\",\"CAD/CAM System\": \"null\",\"Hide patient name\": \"null\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.197Z"
                },
                "606d98a80212a5001852f492": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "605074d67e45b40019989878",
                            "code": null,
                            "value": null,
                            "param": "604f8e97d2ad7e0011328734",
                            "name": "order_id"
                        },
                        {
                            "_id": "605074d67e45b40019989879",
                            "code": null,
                            "value": "CIL",
                            "param": "604f8e97d2ad7e0011328735",
                            "name": "CAD_CAM_System"
                        },
                        {
                            "_id": "605074d67e45b4001998987a",
                            "code": null,
                            "value": false,
                            "param": "604f8e97d2ad7e0011328736",
                            "name": "Hide_patient_name"
                        }
                    ],
                    "_id": "606d98a80212a5001852f492",
                    "name": "Export - Par",
                    "timeout": null,
                    "method": "ExportResto",
                    "numParallel": null,
                    "actionExecutionId": "38af8bf5-939c-41bf-a7a9-d6a144625042-1621339577204",
                    "action": "606d98a80212a5001852f492",
                    "startTime": "2021-05-18T12:06:17.204Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-lab - ExportResto: order_id: null, CAD_CAM_System: CIL, Hide_patient_name: false",
                        "stderr": "",
                        "result": "{\"name\": \"Export_Restorative_Case\",\"params\": {\"order_id\": \"null\",\"CAD/CAM System\": \"CIL\",\"Hide patient name\": \"false\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.262Z"
                }
            },
            "startTime": "2021-05-18T12:06:16.799Z",
            "processIndex": 0,
            "processName": "MIDC Lab final validation",
            "finishTime": "2021-05-18T12:06:17.268Z"
        }
    ],
    "f12e6a2a-b7c0-4e43-b61f-4e96b12ff869": [
        {
            "processId": "606d98a80212a5001852f3d7",
            "iterationIndex": 0,
            "status": "done",
            "uuid": "f12e6a2a-b7c0-4e43-b61f-4e96b12ff869",
            "actions": {
                "606d98a80212a5001852f3d8": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6045cd23d2ad7e00113ea95b",
                            "code": true,
                            "value": "myitero_doctor_user()",
                            "param": "6016fdf53368a10018cf798f",
                            "name": "username"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea95c",
                            "code": true,
                            "value": "myitero_doctor_password()",
                            "param": "6016fdf53368a10018cf7990",
                            "name": "password"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea95d",
                            "code": true,
                            "value": "myitero_doctor_company()",
                            "param": "6016fdf53368a10018cf7991",
                            "name": "company"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea95e",
                            "code": null,
                            "value": "Yes",
                            "param": "6016fdf53368a10018cf7992",
                            "name": "mandatory_block"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3d8",
                    "name": "Login",
                    "timeout": null,
                    "method": "Login",
                    "numParallel": null,
                    "actionExecutionId": "9e825c1e-1581-477e-b1c8-3d2c90089aa2-1621339577298",
                    "action": "606d98a80212a5001852f3d8",
                    "startTime": "2021-05-18T12:06:17.298Z",
                    "retriesLeft": 0,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-doctor - Login: username: kausdoc1@gmail.com, password: Aligner5, company: Kaholo US Clinic D2L, mandatory_block: Yes",
                        "stderr": "",
                        "result": "{\"name\": \"Login\",\"params\": {\"user_name\":\"kausdoc1@gmail.com\",\"password\": \"Aligner5\",\"company\": \"Kaholo US Clinic D2L\",\"mandatory_block\": true}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.355Z"
                },
                "606d98a80212a5001852f3dd": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6045cd23d2ad7e00113ea960",
                            "code": null,
                            "value": null,
                            "param": "6016fdf53368a10018cf7994",
                            "name": "order_id"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3dd",
                    "name": "SearchOrder",
                    "timeout": null,
                    "method": "Search_Order",
                    "numParallel": null,
                    "actionExecutionId": "9fd53dd7-bcb8-4d9a-9cd2-a1d1db9cb7ca-1621339577361",
                    "action": "606d98a80212a5001852f3dd",
                    "startTime": "2021-05-18T12:06:17.361Z",
                    "retriesLeft": 0,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-doctor - Search_Order: order_id: null",
                        "stderr": "",
                        "result": "{\"name\": \"Search_Order\",\"params\": {\"order_id\": \"null\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.417Z"
                },
                "606d98a80212a5001852f3df": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6045cd23d2ad7e00113ea962",
                            "code": null,
                            "value": null,
                            "param": "6016fdf53368a10018cf7996",
                            "name": "order_id"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea963",
                            "code": null,
                            "value": null,
                            "param": null,
                            "name": "rx_fields"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea964",
                            "code": null,
                            "value": null,
                            "param": null,
                            "name": "rx_deafult"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea965",
                            "code": null,
                            "value": "Yes",
                            "param": "6016fdf53368a10018cf7997",
                            "name": "Go_Back_When_Done"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3df",
                    "name": "ViewRx",
                    "timeout": null,
                    "method": "ViewRx",
                    "numParallel": null,
                    "actionExecutionId": "21578a8b-58be-4166-bf83-47eaffe792ab-1621339577423",
                    "action": "606d98a80212a5001852f3df",
                    "startTime": "2021-05-18T12:06:17.423Z",
                    "retriesLeft": 0,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-doctor - ViewRx: order_id: null, rx_fields: null, rx_deafult: null, Go_Back_When_Done: Yes",
                        "stderr": "",
                        "result": "{\"name\": \"ViewRX\",\"params\": {\"order_id\": \"null\",\"rx_deafult\": \"null\",\"Go_Back_When_Done\": true,\"rx_fields\": null}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.479Z"
                },
                "606d98a80212a5001852f3e4": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6045cd23d2ad7e00113ea967",
                            "code": null,
                            "value": null,
                            "param": "6016fdf53368a10018cf7999",
                            "name": "order_id"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3e4",
                    "name": "Search",
                    "timeout": null,
                    "method": "Search_Order",
                    "numParallel": null,
                    "actionExecutionId": "744a50d8-bef4-41b8-81c9-530ddf3b4ff1-1621339577486",
                    "action": "606d98a80212a5001852f3e4",
                    "startTime": "2021-05-18T12:06:17.486Z",
                    "retriesLeft": 0,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-doctor - Search_Order: order_id: null",
                        "stderr": "",
                        "result": "{\"name\": \"Search_Order\",\"params\": {\"order_id\": \"null\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.541Z"
                },
                "606d98a80212a5001852f3e6": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6045cd23d2ad7e00113ea969",
                            "code": null,
                            "value": null,
                            "param": "6016fdf53368a10018cf799b",
                            "name": "order_id"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea96a",
                            "code": null,
                            "value": "Yes",
                            "param": "6016fdf53368a10018cf799c",
                            "name": "jaws_verification"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea96b",
                            "code": null,
                            "value": "Yes",
                            "param": "6016fdf53368a10018cf799d",
                            "name": "Go_Back_When_Done"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3e6",
                    "name": "Viwer",
                    "timeout": null,
                    "method": "View",
                    "numParallel": null,
                    "actionExecutionId": "f6e94530-e892-4b1b-a8d4-5fa6c853674c-1621339577547",
                    "action": "606d98a80212a5001852f3e6",
                    "startTime": "2021-05-18T12:06:17.547Z",
                    "retriesLeft": 0,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-doctor - View: order_id: null, jaws_verification: Yes, Go_Back_When_Done: Yes",
                        "stderr": "",
                        "result": "{\"name\": \"View\",\"params\": {\"order_id\": \"null\",\"jaws_verification\": true,\"Go_Back_When_Done\": true}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.603Z"
                },
                "606d98a80212a5001852f3ea": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6045cd23d2ad7e00113ea96d",
                            "code": null,
                            "value": null,
                            "param": "6016fdf53368a10018cf799f",
                            "name": "order_id"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea96e",
                            "code": null,
                            "value": null,
                            "param": "6016fdf53368a10018cf79a0",
                            "name": "CAD_CAM_System"
                        },
                        {
                            "_id": "6045cd23d2ad7e00113ea96f",
                            "code": null,
                            "value": null,
                            "param": "6016fdf53368a10018cf79a1",
                            "name": "Hide_patient_name"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3ea",
                    "name": "Action #6 ",
                    "timeout": null,
                    "method": "ExportResto",
                    "numParallel": null,
                    "actionExecutionId": "66bda675-4d6c-4e4a-8118-e3996be195be-1621339577609",
                    "action": "606d98a80212a5001852f3ea",
                    "startTime": "2021-05-18T12:06:17.609Z",
                    "retriesLeft": 0,
                    "status": "success",
                    "result": {
                        "stdout": "+ myitero-doctor - ExportResto: order_id: null, CAD_CAM_System: null, Hide_patient_name: null",
                        "stderr": "",
                        "result": "{\"name\": \"Export_Restorative_Case\",\"params\": {\"order_id\": \"null\",\"CAD/CAM System\": \"null\",\"Hide patient name\": \"null\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.668Z"
                }
            },
            "startTime": "2021-05-18T12:06:17.277Z",
            "processIndex": 1,
            "processName": "Process #2",
            "finishTime": "2021-05-18T12:06:17.674Z"
        }
    ],
    "d4af0829-0fce-4c4d-8321-7175358eca4d": [
        {
            "processId": "606d98a80212a5001852f3ee",
            "iterationIndex": 0,
            "status": "done",
            "uuid": "d4af0829-0fce-4c4d-8321-7175358eca4d",
            "actions": {
                "606d98a80212a5001852f3ef": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6016fdf53368a10018cf79a4",
                            "code": true,
                            "value": "wcm_admin_user()",
                            "param": "60168df83368a10018ba650b",
                            "name": "username"
                        },
                        {
                            "_id": "6016fdf53368a10018cf79a5",
                            "code": true,
                            "value": "wcm_admin_password()",
                            "param": "60168df83368a10018ba650c",
                            "name": "password"
                        },
                        {
                            "_id": "6016fdf53368a10018cf79a6",
                            "code": null,
                            "value": "wcm_par",
                            "param": "60168df83368a10018ba650d",
                            "name": "wcm"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3ef",
                    "name": "Login",
                    "timeout": null,
                    "method": "Login",
                    "numParallel": null,
                    "actionExecutionId": "01ea9fff-bff0-45ee-9793-42088e6c34c4-1621339577709",
                    "action": "606d98a80212a5001852f3ef",
                    "startTime": "2021-05-18T12:06:17.709Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ wcm_global - Login: username: iterobiz-test1@aligntech.com, password: Dontusedefaultpassw0rds, wcm: wcm_par",
                        "stderr": "",
                        "result": "{\"name\": \"Login\",\"params\": {\"user_name\":\"iterobiz-test1@aligntech.com\",\"password\": \"Dontusedefaultpassw0rds\",\"wcm\": \"wcm_par\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.766Z"
                },
                "606d98a80212a5001852f3f3": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6016fdf53368a10018cf79a8",
                            "code": null,
                            "value": null,
                            "param": "60168df83368a10018ba650f",
                            "name": "order_id"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3f3",
                    "name": "Search Order",
                    "timeout": null,
                    "method": "Search_Order",
                    "numParallel": null,
                    "actionExecutionId": "6a88fa91-3e3c-424b-b853-44f8a4521af5-1621339577773",
                    "action": "606d98a80212a5001852f3f3",
                    "startTime": "2021-05-18T12:06:17.773Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ wcm_global - Search_Order: order_id: null",
                        "stderr": "",
                        "result": "{\"name\": \"Search_Order\",\"params\": {\"order_id\": \"null\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.830Z"
                },
                "606d98a80212a5001852f3f5": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6016fdf53368a10018cf79aa",
                            "code": true,
                            "value": "getConfiguration('no_wcm')",
                            "param": "60168df83368a10018ba6511",
                            "name": "verification"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3f5",
                    "name": "Verification",
                    "timeout": null,
                    "method": "Verification",
                    "numParallel": null,
                    "actionExecutionId": "12268a12-f650-4d54-b9bb-6938f4656a1c-1621339577838",
                    "action": "606d98a80212a5001852f3f5",
                    "startTime": "2021-05-18T12:06:17.838Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ wcm_global - Verification: verification: [{\"field_name\":\"Order ID\",\"expected_value\":\"\",\"time_out\":0}]",
                        "stderr": "",
                        "result": "{\"name\": \"Verification\",\"params\": {\"Verification_fields\": [{\"field_name\":\"Order ID\",\"expected_value\":\"\",\"time_out\":0}]}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.893Z"
                }
            },
            "startTime": "2021-05-18T12:06:17.686Z",
            "processIndex": 2,
            "processName": "WCM_PAR",
            "finishTime": "2021-05-18T12:06:17.900Z"
        }
    ],
    "05fa41aa-1a41-4887-8eb8-0dd84e16752e": [
        {
            "processId": "606d98a80212a5001852f3f7",
            "iterationIndex": 0,
            "status": "done",
            "uuid": "05fa41aa-1a41-4887-8eb8-0dd84e16752e",
            "actions": {
                "606d98a80212a5001852f3f8": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6010398ec1890a0018ffdf66",
                            "code": true,
                            "value": "wcm_admin_user()",
                            "param": null,
                            "name": "username"
                        },
                        {
                            "_id": "6010398ec1890a0018ffdf67",
                            "code": true,
                            "value": "wcm_admin_password()",
                            "param": null,
                            "name": "password"
                        },
                        {
                            "_id": "6010398ec1890a0018ffdf68",
                            "code": null,
                            "value": "wcm_ctm",
                            "param": null,
                            "name": "wcm"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3f8",
                    "name": "Login",
                    "timeout": null,
                    "method": "Login",
                    "numParallel": null,
                    "actionExecutionId": "1a8122a7-eb17-4f93-b1dd-2072d662ea59-1621339577939",
                    "action": "606d98a80212a5001852f3f8",
                    "startTime": "2021-05-18T12:06:17.939Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ wcm_global - Login: username: iterobiz-test1@aligntech.com, password: Dontusedefaultpassw0rds, wcm: wcm_ctm",
                        "stderr": "",
                        "result": "{\"name\": \"Login\",\"params\": {\"user_name\":\"iterobiz-test1@aligntech.com\",\"password\": \"Dontusedefaultpassw0rds\",\"wcm\": \"wcm_ctm\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:17.997Z"
                },
                "606d98a80212a5001852f3fc": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6010398ec1890a0018ffdf6a",
                            "code": null,
                            "value": null,
                            "param": null,
                            "name": "order_id"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3fc",
                    "name": "Search Order",
                    "timeout": null,
                    "method": "Search_Order",
                    "numParallel": null,
                    "actionExecutionId": "80fd1428-9623-4907-95f5-64a67c80995c-1621339578004",
                    "action": "606d98a80212a5001852f3fc",
                    "startTime": "2021-05-18T12:06:18.004Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ wcm_global - Search_Order: order_id: null",
                        "stderr": "",
                        "result": "{\"name\": \"Search_Order\",\"params\": {\"order_id\": \"null\"}}"
                    },
                    "finishTime": "2021-05-18T12:06:18.062Z"
                },
                "606d98a80212a5001852f3fe": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "6010398ec1890a0018ffdf6c",
                            "code": true,
                            "value": "getConfiguration('no_wcm')",
                            "param": null,
                            "name": "verification"
                        }
                    ],
                    "_id": "606d98a80212a5001852f3fe",
                    "name": "Verification",
                    "timeout": null,
                    "method": "Verification",
                    "numParallel": null,
                    "actionExecutionId": "1c4e9dbd-e757-4ea2-8463-2791003cb3f0-1621339578068",
                    "action": "606d98a80212a5001852f3fe",
                    "startTime": "2021-05-18T12:06:18.068Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ wcm_global - Verification: verification: [{\"field_name\":\"Order ID\",\"expected_value\":\"\",\"time_out\":0}]",
                        "stderr": "",
                        "result": "{\"name\": \"Verification\",\"params\": {\"Verification_fields\": [{\"field_name\":\"Order ID\",\"expected_value\":\"\",\"time_out\":0}]}}"
                    },
                    "finishTime": "2021-05-18T12:06:18.126Z"
                }
            },
            "startTime": "2021-05-18T12:06:17.915Z",
            "processIndex": 3,
            "processName": "WCM_CTM",
            "finishTime": "2021-05-18T12:06:18.133Z"
        }
    ],
    "4ee4ab00-07e6-494b-bec3-c37accd82acd": [
        {
            "processId": "606d98a80212a5001852f429",
            "iterationIndex": 0,
            "status": "done",
            "uuid": "4ee4ab00-07e6-494b-bec3-c37accd82acd",
            "actions": {
                "609d1fab4ca755003449e151": {
                    "retries": 1,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "609d1fab4ca755003449e152",
                            "code": true,
                            "value": "mat_user()",
                            "param": "60168df83368a10018ba6544",
                            "name": "username"
                        },
                        {
                            "_id": "609d1fab4ca755003449e153",
                            "code": null,
                            "value": null,
                            "param": "60168df83368a10018ba6545",
                            "name": "order_id"
                        },
                        {
                            "_id": "609d1fab4ca755003449e154",
                            "code": true,
                            "value": "getConfiguration('Order Information int')",
                            "param": "60168df83368a10018ba6546",
                            "name": "order_information_fields"
                        },
                        {
                            "_id": "609d1fab4ca755003449e155",
                            "code": true,
                            "value": "getConfiguration('Work Orders')",
                            "param": "60168df83368a10018ba6547",
                            "name": "work_orders_fields"
                        },
                        {
                            "_id": "609d1fab4ca755003449e156",
                            "code": true,
                            "value": "getConfiguration('Rx_fields')",
                            "param": "60168df83368a10018ba6548",
                            "name": "rx_fields"
                        },
                        {
                            "_id": "609d1fab4ca755003449e157",
                            "code": null,
                            "value": null,
                            "param": null,
                            "name": "rx_deafult"
                        },
                        {
                            "_id": "609d1fab4ca755003449e158",
                            "code": null,
                            "value": null,
                            "param": "60168df83368a10018ba6549",
                            "name": "retries"
                        }
                    ],
                    "_id": "609d1fab4ca755003449e151",
                    "name": "login and verify",
                    "timeout": null,
                    "method": "FieldsVerification",
                    "numParallel": null,
                    "actionExecutionId": "71a4957e-ea71-4df4-9337-6e9724325798-1621339578176",
                    "action": "609d1fab4ca755003449e151",
                    "startTime": "2021-05-18T12:06:18.176Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ MAT - FieldsVerification: username: qa_sw@aligntech.com, order_id: null, order_information_fields: [{\"field_name\":\"Order Status:\",\"expected_value\":\"Active\",\"time_out_seconds\":\"120\"},{\"field_name\":\"State:\",\"expected_value\":\"Interpretation2\",\"time_out_seconds\":\"120\"},{\"field_name\":\"First Name:\",\"expected_value\":\"Resto_{{uniqe_suffix}}\",\"time_out_seconds\":\"120\"},{\"field_name\":\"Order ID:\",\"expected_value\":\"{{order_id}}\",\"time_out_seconds\":\"120\"}], work_orders_fields: [{\"bill_or_work\":\"Scanning\",\"expected_value\":\"Completed\",\"time_out_seconds\":\"0\"},{\"bill_or_work\":\"Scanning\",\"expected_value\":\"Completed\",\"time_out_seconds\":\"0\",\"file_fields\":{\"file_type\":\"Json\",\"fields_verifications\":[{\"field_name\":\"ToSrvr\",\"expected_value\":\"ACS\"},{\"field_name\":\"HeaderID\",\"expected_value\":\"{{order_id}}\"}]}}], rx_fields: [{\"field_name\":\"Last Name:\",\"expected_value\":\"Testing1\"}], rx_deafult: null, retries: null",
                        "stderr": "",
                        "result": "{\"stage\": \"mat\",\"method\": \"FieldsVerification\",\"user_name\": \"qa_sw@aligntech.com\",\"order_id\": \"null\",\"exception\": \"\",\"status\": \"\",\"retries\": null,\"attempts\": 0,\"next_step\": \"\",\"order_information_fields\": [{\"field_name\":\"Order Status:\",\"expected_value\":\"Active\",\"time_out_seconds\":\"120\"},{\"field_name\":\"State:\",\"expected_value\":\"Interpretation2\",\"time_out_seconds\":\"120\"},{\"field_name\":\"First Name:\",\"expected_value\":\"Resto_{{uniqe_suffix}}\",\"time_out_seconds\":\"120\"},{\"field_name\":\"Order ID:\",\"expected_value\":\"{{order_id}}\",\"time_out_seconds\":\"120\"}],\"work_orders_fields\": [{\"bill_or_work\":\"Scanning\",\"expected_value\":\"Completed\",\"time_out_seconds\":\"0\"},{\"bill_or_work\":\"Scanning\",\"expected_value\":\"Completed\",\"time_out_seconds\":\"0\",\"file_fields\":{\"file_type\":\"Json\",\"fields_verifications\":[{\"field_name\":\"ToSrvr\",\"expected_value\":\"ACS\"},{\"field_name\":\"HeaderID\",\"expected_value\":\"{{order_id}}\"}]}}],\"rx_deafult\": \"null\",\"rx_fields\": [{\"field_name\":\"Last Name:\",\"expected_value\":\"Testing1\"}]}"
                    },
                    "finishTime": "2021-05-18T12:06:18.241Z"
                }
            },
            "startTime": "2021-05-18T12:06:18.149Z",
            "processIndex": 4,
            "processName": "MAT_Done_Event",
            "finishTime": "2021-05-18T12:06:18.253Z"
        }
    ],
    "9e285ff6-9faa-4424-99b4-4ea16494327f": [
        {
            "processId": "609c0c47447627003f948447",
            "iterationIndex": 0,
            "status": "running",
            "uuid": "9e285ff6-9faa-4424-99b4-4ea16494327f",
            "actions": {
                "60a3adb3cb8f28003435d8ab": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "60a3adb3cb8f28003435d8ac",
                            "code": true,
                            "value": "print()",
                            "param": "609d588f3d4f4200351074bc",
                            "name": "COMMANDS"
                        }
                    ],
                    "_id": "60a3adb3cb8f28003435d8ab",
                    "name": "Action #1 ",
                    "timeout": null,
                    "method": "execute",
                    "numParallel": null,
                    "actionExecutionId": "0b7ca692-3ae9-4414-9a58-107f9fbc547c-1621339578304",
                    "action": "60a3adb3cb8f28003435d8ab",
                    "startTime": "2021-05-18T12:06:18.304Z",
                    "retriesLeft": 0,
                    "status": "running"
                }
            },
            "startTime": "2021-05-18T12:06:18.275Z",
            "processIndex": 5,
            "processName": "print"
        }
    ]
}

const configuration = {
	"uuid": "",
    "uniqe_suffix":"",
	"name": "Restorative_Case_One_Prep_E2E",
	"order_id": "",
	"environment": "ppr",
	"worker_number": 1,
	"json_folder": "",
    "test":"ITEROBIZ-56520 - D2L - ACS - physical model request + Notifications flow - EU region",
    "debug_report_name":"PPR_logs",
	"current_stage": "stage_1",
    "unique_scanner":false,
    "scanner_agent_tags":""
};

module.exports = {processes, configuration}


