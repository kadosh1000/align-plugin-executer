/**
 * Here is some test data in order to test the `getMessageJson` method
 */
//  const processes = {
//     "8b40a89e-a4b3-4e4f-9368-3e16c8ae228e": [
//         {
//             "status": "done",
//             "startNode": true
//         }
//     ],
//     "70c1e598-f72a-4ab0-afa2-78959c47e5ad": [
//         {
//             "processId": "6088031ba2ab2d0035cb273b",
//             "iterationIndex": 0,
//             "status": "done",
//             "uuid": "70c1e598-f72a-4ab0-afa2-78959c47e5ad",
//             "actions": {
//                 "6088031ba2ab2d0035cb273c": {
//                     "retries": 0,
//                     "mandatory": null,
//                     "isEnabled": true,
//                     "params": [
//                         {
//                             "_id": "6088031ba2ab2d0035cb273d",
//                             "code": true,
//                             "value": "wcm_admin_user()",
//                             "param": null,
//                             "name": "username"
//                         },
//                         {
//                             "_id": "6088031ba2ab2d0035cb273e",
//                             "code": true,
//                             "value": "wcm_admin_password()",
//                             "param": null,
//                             "name": "password"
//                         },
//                         {
//                             "_id": "6088031ba2ab2d0035cb273f",
//                             "code": null,
//                             "value": "60589ed16f02ea0011c58960",
//                             "param": null,
//                             "name": "mandatory_block"
//                         }
//                     ],
//                     "_id": "6088031ba2ab2d0035cb273c",
//                     "name": "Action #1 ",
//                     "timeout": null,
//                     "method": "Login",
//                     "numParallel": null,
//                     "actionExecutionId": "8540b52e-0edc-4bf9-b64d-c5a76e57ba29-1620654317416",
//                     "action": "6088031ba2ab2d0035cb273c",
//                     "startTime": "2021-05-10T13:45:17.416Z",
//                     "retriesLeft": 0,
//                     "status": "success",
//                     "result": {
//                         "stdout": "+ myitero-lab - Login: username: , password: , mandatory_block: undefined",
//                         "stderr": "",
//                         "result": JSON.stringify(
//                             {
//                                 "stage": "mat",
//                                 "method": "${method}",
//                                 "status": "",
//                                 "retries": 1,
//                                 "attempts": 0,
//                                 "user_name": "${action.params.username}",
//                                 "order_id": "${action.params.order_id}",
//                                 "exception": "",
//                                 "next_step": "",
//                                 "order_information_fields": [],
//                                 "work_orders_fields": [],
//                                 "rx_deafult": true,
//                                 "rx_fields": []
//                         })
//                     },
//                     "finishTime": "2021-05-10T13:45:17.487Z"
//                 },
//                 // "6088031ba2ab2d0035cb2740": {
//                 //     "retries": 0,
//                 //     "mandatory": null,
//                 //     "isEnabled": true,
//                 //     "params": [
//                 //         {
//                 //             "_id": "6088031ba2ab2d0035cb2741",
//                 //             "code": null,
//                 //             "value": null,
//                 //             "param": null,
//                 //             "name": "order_id"
//                 //         }
//                 //     ],
//                 //     "_id": "6088031ba2ab2d0035cb2740",
//                 //     "name": "Action #2 ",
//                 //     "timeout": null,
//                 //     "method": "Search_Order",
//                 //     "numParallel": null,
//                 //     "actionExecutionId": "f355c353-fd9d-4179-bca4-2770564290ae-1620654317494",
//                 //     "action": "6088031ba2ab2d0035cb2740",
//                 //     "startTime": "2021-05-10T13:45:17.494Z",
//                 //     "retriesLeft": 0,
//                 //     "status": "success",
//                 //     "result": {
//                 //         "stdout": "+ myitero-lab - Search_Order: order_id: null",
//                 //         "stderr": "",
//                 //         "result": JSON.stringify({'name': 'Search_Order','params': {'order_id': 'null'}})
//                 //     },
//                 //     "finishTime": "2021-05-10T13:45:17.548Z"
//                 // }
//             },
//             "startTime": "2021-05-10T13:45:17.398Z",
//             "processIndex": 0,
//             "processName": "Process #1",
//             "finishTime": "2021-05-10T13:45:17.555Z"
//         }
//     ]
// };

 const processes = {
    "8b40a89e-a4b3-4e4f-9368-3e16c8ae228e": [
        {
            "status": "done",
            "startNode": true
        }
    ],
    "000a2a7e-5896-4bb3-a24b-4573f47871b3": [
        {
            "processId": "606eaf3b0212a50018ad9330",
            "iterationIndex": 0,
            "status": "done",
            "uuid": "000a2a7e-5896-4bb3-a24b-4573f47871b3",
            "actions": {
                "60a3aa2ecb8f28003434a477": {
                    "retries": 5,
                    "mandatory": true,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "60a3aa2ecb8f28003434a478",
                            "code": null,
                            "value": "MXWCM_iTero_Model_QC@qa.com",
                            "param": null,
                            "name": "username"
                        },
                        {
                            "_id": "60a3aa2ecb8f28003434a479",
                            "code": null,
                            "value": "Aligner5",
                            "param": null,
                            "name": "password"
                        },
                        {
                            "_id": "60a3aa2ecb8f28003434a47a",
                            "code": null,
                            "value": null,
                            "param": null,
                            "name": "order_id"
                        },
                        {
                            "_id": "60a3aa2ecb8f28003434a47b",
                            "code": null,
                            "value": 1,
                            "param": null,
                            "name": "retries"
                        }
                    ],
                    "_id": "60a3aa2ecb8f28003434a477",
                    "name": "Action #1 ",
                    "timeout": null,
                    "method": "sendModelQC",
                    "numParallel": null,
                    "actionExecutionId": "9392d576-6f06-4d39-84ae-1c7a3d306d0c-1621410428849",
                    "action": "60a3aa2ecb8f28003434a477",
                    "startTime": "2021-05-19T07:47:08.849Z",
                    "retriesLeft": 5,
                    "status": "success",
                    "result": {
                        "stdout": "+ model_qc - sendModelQC: username: MXWCM_iTero_Model_QC@qa.com, password: Aligner5, order_id: null, retries: 1",
                        "stderr": "",
                        "result": "{\"stage\": \"model_qc\",\"method\": \"sendModelQC\",\"status\": \"\",\"phase\":\"\",\"retries\": 1,\"attempts\": 0,\"user_name\": \"MXWCM_iTero_Model_QC@qa.com\",\"password\": \"Aligner5\",\"exception\": \"\",\"test_report\": \"\",\"order_id\": \"null\",\"next_step\": \"\"}"
                    },
                    "finishTime": "2021-05-19T07:47:08.915Z"
                }
            },
            "startTime": "2021-05-19T07:47:08.832Z",
            "processIndex": 0,
            "processName": "Process #1",
            "finishTime": "2021-05-19T07:47:08.921Z"
        }
    ],
    "9e285ff6-9faa-4424-99b4-4ea16494327f": [
        {
            "processId": "609c0c47447627003f948447",
            "iterationIndex": 0,
            "status": "running",
            "uuid": "9e285ff6-9faa-4424-99b4-4ea16494327f",
            "actions": {
                "60a3adb3cb8f28003435d8ab": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "60a3adb3cb8f28003435d8ac",
                            "code": true,
                            "value": "print()",
                            "param": "609d588f3d4f4200351074bc",
                            "name": "COMMANDS"
                        }
                    ],
                    "_id": "60a3adb3cb8f28003435d8ab",
                    "name": "Action #1 ",
                    "timeout": null,
                    "method": "execute",
                    "numParallel": null,
                    "actionExecutionId": "7309916c-be5a-4498-a638-c3116ea7f4aa-1621410428947",
                    "action": "60a3adb3cb8f28003435d8ab",
                    "startTime": "2021-05-19T07:47:08.947Z",
                    "retriesLeft": 0,
                    "status": "running"
                }
            },
            "startTime": "2021-05-19T07:47:08.929Z",
            "processIndex": 1,
            "processName": "print"
        }
    ]
}

const configuration = {
	"uuid": "",
    "uniqe_suffix":"",
	"name": "Restorative_Case_One_Prep_E2E",
	"order_id": "",
	"environment": "ppr",
	"worker_number": 1,
	"json_folder": "",
    "test":"ITEROBIZ-56520 - D2L - ACS - physical model request + Notifications flow - EU region",
    "debug_report_name":"PPR_logs",
	"current_stage": "stage_1",
    "unique_scanner":false,
    "scanner_agent_tags":""
};

module.exports = {processes, configuration}


