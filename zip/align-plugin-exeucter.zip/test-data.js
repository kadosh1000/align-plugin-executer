/**
 * Here is some test data in order to test the `getMessageJson` method
 */
//  const processes = {
//     "8b40a89e-a4b3-4e4f-9368-3e16c8ae228e": [
//         {
//             "status": "done",
//             "startNode": true
//         }
//     ],
//     "70c1e598-f72a-4ab0-afa2-78959c47e5ad": [
//         {
//             "processId": "6088031ba2ab2d0035cb273b",
//             "iterationIndex": 0,
//             "status": "done",
//             "uuid": "70c1e598-f72a-4ab0-afa2-78959c47e5ad",
//             "actions": {
//                 "6088031ba2ab2d0035cb273c": {
//                     "retries": 0,
//                     "mandatory": null,
//                     "isEnabled": true,
//                     "params": [
//                         {
//                             "_id": "6088031ba2ab2d0035cb273d",
//                             "code": true,
//                             "value": "wcm_admin_user()",
//                             "param": null,
//                             "name": "username"
//                         },
//                         {
//                             "_id": "6088031ba2ab2d0035cb273e",
//                             "code": true,
//                             "value": "wcm_admin_password()",
//                             "param": null,
//                             "name": "password"
//                         },
//                         {
//                             "_id": "6088031ba2ab2d0035cb273f",
//                             "code": null,
//                             "value": "60589ed16f02ea0011c58960",
//                             "param": null,
//                             "name": "mandatory_block"
//                         }
//                     ],
//                     "_id": "6088031ba2ab2d0035cb273c",
//                     "name": "Action #1 ",
//                     "timeout": null,
//                     "method": "Login",
//                     "numParallel": null,
//                     "actionExecutionId": "8540b52e-0edc-4bf9-b64d-c5a76e57ba29-1620654317416",
//                     "action": "6088031ba2ab2d0035cb273c",
//                     "startTime": "2021-05-10T13:45:17.416Z",
//                     "retriesLeft": 0,
//                     "status": "success",
//                     "result": {
//                         "stdout": "+ myitero-lab - Login: username: , password: , mandatory_block: undefined",
//                         "stderr": "",
//                         "result": JSON.stringify(
//                             {
//                                 "stage": "mat",
//                                 "method": "${method}",
//                                 "status": "",
//                                 "retries": 1,
//                                 "attempts": 0,
//                                 "user_name": "${action.params.username}",
//                                 "order_id": "${action.params.order_id}",
//                                 "exception": "",
//                                 "next_step": "",
//                                 "order_information_fields": [],
//                                 "work_orders_fields": [],
//                                 "rx_deafult": true,
//                                 "rx_fields": []
//                         })
//                     },
//                     "finishTime": "2021-05-10T13:45:17.487Z"
//                 },
//                 // "6088031ba2ab2d0035cb2740": {
//                 //     "retries": 0,
//                 //     "mandatory": null,
//                 //     "isEnabled": true,
//                 //     "params": [
//                 //         {
//                 //             "_id": "6088031ba2ab2d0035cb2741",
//                 //             "code": null,
//                 //             "value": null,
//                 //             "param": null,
//                 //             "name": "order_id"
//                 //         }
//                 //     ],
//                 //     "_id": "6088031ba2ab2d0035cb2740",
//                 //     "name": "Action #2 ",
//                 //     "timeout": null,
//                 //     "method": "Search_Order",
//                 //     "numParallel": null,
//                 //     "actionExecutionId": "f355c353-fd9d-4179-bca4-2770564290ae-1620654317494",
//                 //     "action": "6088031ba2ab2d0035cb2740",
//                 //     "startTime": "2021-05-10T13:45:17.494Z",
//                 //     "retriesLeft": 0,
//                 //     "status": "success",
//                 //     "result": {
//                 //         "stdout": "+ myitero-lab - Search_Order: order_id: null",
//                 //         "stderr": "",
//                 //         "result": JSON.stringify({'name': 'Search_Order','params': {'order_id': 'null'}})
//                 //     },
//                 //     "finishTime": "2021-05-10T13:45:17.548Z"
//                 // }
//             },
//             "startTime": "2021-05-10T13:45:17.398Z",
//             "processIndex": 0,
//             "processName": "Process #1",
//             "finishTime": "2021-05-10T13:45:17.555Z"
//         }
//     ]
// };

 const processes = {
    "8b40a89e-a4b3-4e4f-9368-3e16c8ae228e": [
        {
            "status": "done",
            "startNode": true
        }
    ],
    "f7c7782a-7678-4d35-93a6-8acee92f2aec": [
        {
            "processId": "609cdefe158d6600346f516d",
            "iterationIndex": 0,
            "status": "done",
            "uuid": "f7c7782a-7678-4d35-93a6-8acee92f2aec",
            "actions": {
                "609cdefe158d6600346f516e": {
                    "retries": 1,
                    "mandatory": true,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "605b210cbde4600011d2e751",
                            "code": true,
                            "value": "getUniqueParam(\"Resto\")",
                            "param": null,
                            "name": "first_name"
                        },
                        {
                            "_id": "605b210cbde4600011d2e752",
                            "code": null,
                            "value": "Patient1",
                            "param": null,
                            "name": "last_name"
                        },
                        {
                            "_id": "605b210cbde4600011d2e753",
                            "code": true,
                            "value": "scanner_resto_doctor_email()",
                            "param": null,
                            "name": "doctor_email"
                        },
                        {
                            "_id": "605b210cbde4600011d2e754",
                            "code": true,
                            "value": "scanner_resto_doctor_name()",
                            "param": null,
                            "name": "doctor_name"
                        },
                        {
                            "_id": "605b210cbde4600011d2e755",
                            "code": true,
                            "value": "scanner_resto_doctor_password()",
                            "param": null,
                            "name": "doctor_pass"
                        },
                        {
                            "_id": "605b210cbde4600011d2e756",
                            "code": true,
                            "value": "scanner_resto_doctor_company_id()",
                            "param": null,
                            "name": "company_id"
                        },
                        {
                            "_id": "605b210cbde4600011d2e757",
                            "code": true,
                            "value": "scanner_resto_doctor_lab_name()",
                            "param": null,
                            "name": "lab_name"
                        },
                        {
                            "_id": "605b210cbde4600011d2e758",
                            "code": null,
                            "value": "Local",
                            "param": null,
                            "name": "rx_from"
                        },
                        {
                            "_id": "605b210cbde4600011d2e759",
                            "code": null,
                            "value": "Restorative",
                            "param": null,
                            "name": "case_type"
                        },
                        {
                            "_id": "605b210cbde4600011d2e75a",
                            "code": null,
                            "value": "Full_Jaw_1_prep",
                            "param": null,
                            "name": "model_type"
                        },
                        {
                            "_id": "605b210cbde4600011d2e75b",
                            "code": null,
                            "value": "true",
                            "param": null,
                            "name": "check_viewer"
                        },
                        {
                            "_id": "605b210cbde4600011d2e75c",
                            "code": null,
                            "value": "true",
                            "param": null,
                            "name": "check_rx"
                        },
                        {
                            "_id": "605b210cbde4600011d2e75d",
                            "code": null,
                            "value": 1,
                            "param": null,
                            "name": "retries"
                        }
                    ],
                    "_id": "609cdefe158d6600346f516e",
                    "name": "Case From Web",
                    "timeout": null,
                    "method": "CreateNewOrder",
                    "numParallel": null,
                    "actionExecutionId": "133a6d6f-616a-4a48-a485-0827288f7754-1620906906081",
                    "action": "609cdefe158d6600346f516e",
                    "startTime": "2021-05-13T11:55:06.081Z",
                    "retriesLeft": 1,
                    "status": "success",
                    "result": {
                        "stdout": "+ Scanner - CreateNewOrder: first_name: Resto_undefined, last_name: Patient1, doctor_email: , doctor_name: , doctor_pass: , company_id: , lab_name: , rx_from: Local, case_type: Restorative, model_type: Full_Jaw_1_prep, check_viewer: true, check_rx: true, retries: 1",
                        "stderr": "",
                        "result": "{\"stage\": \"scanner\",\"method\": \"CreateNewOrder\",\"status\": \"\",\"order_id\": \"\",\"first_name\": \"Resto_undefined\",\"last_name\": \"Patient1\",\"doctor_pass\": \"\",\"doctor_email\": \"\",\"doctor_name\": \"\",\"company_id\": \"\",\"agent\": \"\",\"lab_name\": \"\",\"rx_from\": \"Local\",\"case_type\": \"Restorative\",\"model_type\": \"Full_Jaw_1_prep\",\"retries\": 1,\"attempts\": 0,\"check_viewer\": true,\"check_rx\": true,\"next_step\": \"\"}"
                    },
                    "finishTime": "2021-05-13T11:55:06.144Z"
                }
            },
            "startTime": "2021-05-13T11:55:06.062Z",
            "processIndex": 0,
            "processName": "Process #1",
            "finishTime": "2021-05-13T11:55:06.152Z"
        }
    ],
    "0cdf6623-e373-4ae8-a727-663420f12d8f": [
        {
            "processId": "609cdefe158d6600346f522c",
            "iterationIndex": 0,
            "status": "running",
            "uuid": "0cdf6623-e373-4ae8-a727-663420f12d8f",
            "actions": {
                "609d139808eb4e00355e4ab3": {
                    "retries": 0,
                    "mandatory": null,
                    "isEnabled": true,
                    "params": [
                        {
                            "_id": "609d139808eb4e00355e4ab4",
                            "code": true,
                            "value": "print()",
                            "param": null,
                            "name": "COMMANDS"
                        }
                    ],
                    "_id": "609d139808eb4e00355e4ab3",
                    "name": "Action #1 ",
                    "timeout": null,
                    "method": "execute",
                    "numParallel": null,
                    "actionExecutionId": "73c6ae1c-e8d8-47ab-98c8-80cdf3a3d5f1-1620906906180",
                    "action": "609d139808eb4e00355e4ab3",
                    "startTime": "2021-05-13T11:55:06.180Z",
                    "retriesLeft": 0,
                    "status": "running"
                }
            },
            "startTime": "2021-05-13T11:55:06.160Z",
            "processIndex": 1,
            "processName": "Process #2"
        }
    ]
}

const configuration = {
	"uuid": "",
    "uniqe_suffix":"",
	"name": "Restorative_Case_One_Prep_E2E",
	"order_id": "",
	"environment": "ppr",
	"worker_number": 1,
	"json_folder": "",
    "test":"ITEROBIZ-56520 - D2L - ACS - physical model request + Notifications flow - EU region",
    "debug_report_name":"PPR_logs",
	"current_stage": "stage_1",
    "unique_scanner":false,
    "scanner_agent_tags":""
};

module.exports = {processes, configuration}


